* dist : contains binaries
* docs : contains documentation
* examples : contains examples
* sources : contains sources of the client side of the APIs
* versions
	- COM API 2.0
	- COM 1207.01
