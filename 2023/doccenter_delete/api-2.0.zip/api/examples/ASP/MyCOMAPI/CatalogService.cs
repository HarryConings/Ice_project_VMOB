using System;
using System.Collections.Generic;
using System.Text;
using be.gfdi.com.COMHelper;
using be.gfdi.com.COMHelper.GEDCatalogService;


namespace MyCOMAPI
{
    [System.Runtime.InteropServices.ComVisible(true)]
    public class CatalogService
    {
        public string findInCatalogFromASP(){
            
			ServiceLocator locator = new ServiceLocator("apps.jablux.cpc998.be","526");
			CatalogService service = locator.getCatalogService("MyUser","MyPassword","nl");
            
			FindByParametersRequest parameters = new FindByParametersRequest();
			parameters.pageSize = 20;
			parameters.pageSizeSpecified = true;
			parameters.pageNumber = 1;
			parameters.pageNumberSpecified = true;
			parameters.thirdOrg = "526";
			parameters.thirdCodeType = "EXID";
			parameters.thirdCodeValue = "0810014833584";

			try
			{
				GEDEvent[] list = service.findByParameters(parameters);
				if (list != null)
				{
					string s = "size = "+list.Length + "\n";
					foreach(GEDEvent evt in list)
					{
						s+=evt.key + " " + evt.docTypeLabel + "\n";
					}
					return s;
				}
				else
				{
					return "No result";
				}
			}
			catch(System.Web.Services.Protocols.SoapException exception)
			{
				COMGEDException ex = (COMGEDException)COMGEDException.getException(exception);
				return "ERROR : Code = " + ex.errorCode + "\nMessage = " + ex.errorMessage + "\nStacktrace = " + ex.errorStackTrace;
			}
			catch(System.Net.WebException ex)
			{
				this.Cursor = Cursors.Default;
				return "ERROR : Message=" + ex.Message;
			}
        }

    }
}
